uvicorn app.main:app --reload

docker build -t rdf-orders .

docker run -d --name rdf-orders -p 80:80 rdf-orders